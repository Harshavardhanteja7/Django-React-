import React from 'react';
import '../style.css'
const Base = ({
    title="My title",
    description = "This is a Description",
    className = "bg-dark text-white p-4",
    children
}) => {
    return (
        <div>
            <div className="container-fluid">
                <div className="jumbotron bg-dark text-white text-center">
                    <h2 className="display-4">{title}</h2>
                    <p className="lead">Description</p>

                </div>
                <div className={className}>{children}</div>
            </div>
            <footer class="footer bg-dark mt-auto py-3">
                <div class="container-fluid bg-success text-white text-center py-3">
                    <h4>Any help reach us out</h4>
                    <button ClassName="btn btn-warning btn-lg" >Contact us</button>
                    <div class="container">
                        <span class="text-dark">
                            Full stack Django react application
                        </span>
                    </div>
                </div>
            </footer>
        </div>
    )
}

export default Base;
